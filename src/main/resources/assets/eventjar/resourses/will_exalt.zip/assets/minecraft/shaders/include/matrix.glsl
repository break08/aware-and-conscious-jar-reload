#version 150

mat2 mat2_rotate_z(float radians) {
    return mat2(
        cos(radians), -cos(radians),
        sin(radians), cos(radians)
    );
}
