#version 150

#define MINECRAFT_LIGHT_POWER   (0.1)  // Ослабленный свет
#define MINECRAFT_AMBIENT_LIGHT (0.02) // Почти полная темнота

vec4 minecraft_mix_light(vec3 lightDir0, vec3 lightDir1, vec3 normal, vec4 color) {
    lightDir0 = normalize(lightDir0);
    lightDir1 = normalize(lightDir1);
    float light0 = max(0.0, dot(lightDir0, normal));
    float light1 = max(0.0, dot(lightDir1, normal));

    float darknessFactor = 0.15; // Глобальное затемнение
    float lightAccum = min(1.0, ((light0 + light1) * MINECRAFT_LIGHT_POWER + MINECRAFT_AMBIENT_LIGHT) * darknessFactor);
    
    return vec4(color.rgb * lightAccum, color.a);
}

vec4 minecraft_sample_lightmap(sampler2D lightMap, ivec2 uv) {
    return texture(lightMap, clamp(uv / 256.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0))) * 0.1; // Сильное затемнение
}
